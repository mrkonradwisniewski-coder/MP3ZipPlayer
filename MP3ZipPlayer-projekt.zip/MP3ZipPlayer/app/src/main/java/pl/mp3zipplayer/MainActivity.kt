/*
 * MP3ZipPlayer – Google TV / Android TV
 *
 * === app/build.gradle.kts (fragmenty) ===
 * android { namespace = "pl.mp3zipplayer"; compileSdk = 34
 *   defaultConfig { applicationId = "pl.mp3zipplayer"; minSdk = 24; targetSdk = 34 }
 *   kotlinOptions { jvmTarget = "17" } }
 * dependencies { implementation("androidx.media3:media3-exoplayer:1.4.1") }
 *
 * === AndroidManifest.xml ===
 * <uses-feature android:name="android.software.leanback" android:required="false"/>
 * <uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
 * <application android:label="MP3ZipPlayer" android:theme="@android:style/Theme.Material.NoActionBar">
 *   <activity android:name=".MainActivity" android:exported="true">
 *     <intent-filter>
 *       <action android:name="android.intent.action.MAIN"/>
 *       <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>
 *       <category android:name="android.intent.category.LAUNCHER"/>
 *     </intent-filter>
 *     <intent-filter>
 *       <action android:name="android.intent.action.VIEW"/>
 *       <category android:name="android.intent.category.DEFAULT"/>
 *       <data android:mimeType="application/zip"/>
 *     </intent-filter>
 *   </activity>
 * </application>
 *
 * Sterowanie pilotem: OK = play/pauza, lewo/prawo = -/+30 s,
 * góra/dół = poprzedni/następny plik, MENU (lub OK gdy brak zipa) = wybór zip.
 */
package pl.mp3zipplayer

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private class Track(val name: String, val file: File, var durMs: Long = 0)

    private lateinit var player: ExoPlayer
    private lateinit var cover: ImageView
    private lateinit var title: TextView
    private lateinit var list: ListView
    private lateinit var fileLeft: TextView
    private lateinit var totalLeft: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private val tracks = mutableListOf<Track>()
    private val ui = Handler(Looper.getMainLooper())
    private val audioExt = setOf("mp3", "m4a", "m4b", "ogg", "opus", "flac", "wav", "aac")
    private val imgExt = setOf("jpg", "jpeg", "png", "webp")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi()
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(m: MediaItem?, r: Int) = highlight()
        })
        ui.post(ticker)
        val uri = intent?.data
        if (uri != null) loadZip(uri) else pickZip()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.BLACK); setPadding(48, 32, 48, 32)
        }
        cover = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(cover, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 0, 0, 0) }
        title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 26f; text = "MP3ZipPlayer" }
        list = ListView(this).apply { isFocusable = false; choiceMode = ListView.CHOICE_MODE_SINGLE }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_activated_1, mutableListOf<String>())
        list.adapter = adapter
        fileLeft = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 22f }
        totalLeft = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 22f }
        right.addView(title)
        right.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        right.addView(fileLeft); right.addView(totalLeft)
        root.addView(right, LinearLayout.LayoutParams(0, -1, 1.3f))
        setContentView(root)
    }

    private fun pickZip() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
        }, 1)
    }

    @Deprecated("ok")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        d?.data?.let { loadZip(it) }
    }

    private fun natural(s: String) = Regex("\\d+|\\D+").findAll(s.lowercase()).map {
        it.value.let { v -> if (v[0].isDigit()) v.padStart(12, '0') else v }
    }.joinToString("")

    private fun loadZip(uri: Uri) {
        title.text = "Rozpakowuję…"
        Thread {
            val dir = File(cacheDir, "book").apply { deleteRecursively(); mkdirs() }
            val found = mutableListOf<Pair<String, File>>()
            var coverFile: File? = null; var coverScore = -1
            var i = 0
            ZipInputStream(contentResolver.openInputStream(uri)).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    if (!e.isDirectory) {
                        val base = e.name.substringAfterLast('/')
                        val ext = base.substringAfterLast('.', "").lowercase()
                        if (ext in audioExt || ext in imgExt) {
                            val f = File(dir, "${i++}_$base")
                            f.outputStream().use { zis.copyTo(it) }
                            if (ext in audioExt) found += e.name to f
                            else {
                                val n = base.lowercase()
                                val sc = when {
                                    "cover" in n || "okładka" in n || "okladka" in n -> 3
                                    "folder" in n || "front" in n || "album" in n -> 2
                                    else -> 1
                                }
                                if (sc > coverScore) { coverScore = sc; coverFile = f }
                            }
                        }
                    }
                    e = zis.nextEntry
                }
            }
            found.sortBy { natural(it.first) }
            val list = found.map { Track(it.first.substringAfterLast('/').substringBeforeLast('.'), it.second) }
            val mmr = MediaMetadataRetriever()
            for (t in list) {
                mmr.setDataSource(t.file.absolutePath)
                t.durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0
            }
            var bmp = coverFile?.let { BitmapFactory.decodeFile(it.absolutePath) }
            if (bmp == null && list.isNotEmpty()) {
                mmr.setDataSource(list[0].file.absolutePath)
                mmr.embeddedPicture?.let { bmp = BitmapFactory.decodeByteArray(it, 0, it.size) }
            }
            mmr.release()
            runOnUiThread {
                tracks.clear(); tracks.addAll(list)
                adapter.clear(); adapter.addAll(list.map { it.name })
                cover.setImageBitmap(bmp)
                title.text = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "MP3ZipPlayer"
                player.setMediaItems(list.map { MediaItem.fromUri(Uri.fromFile(it.file)) })
                player.prepare(); player.play(); highlight()
            }
        }.start()
    }

    private fun highlight() {
        val i = player.currentMediaItemIndex
        if (i in tracks.indices) { list.setItemChecked(i, true); list.smoothScrollToPosition(i) }
    }

    private fun fmt(ms: Long): String {
        val s = (ms.coerceAtLeast(0)) / 1000
        return "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    }

    private val ticker = object : Runnable {
        override fun run() {
            val i = player.currentMediaItemIndex
            if (i in tracks.indices) {
                val leftFile = tracks[i].durMs - player.currentPosition
                val leftTotal = leftFile + tracks.drop(i + 1).sumOf { it.durMs }
                fileLeft.text = "Do końca pliku: ${fmt(leftFile)}"
                totalLeft.text = "Do końca wszystkich: ${fmt(leftTotal)}"
            }
            ui.postDelayed(this, 500)
        }
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        when (k) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ->
                if (tracks.isEmpty()) pickZip() else if (player.isPlaying) player.pause() else player.play()
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> player.seekTo(player.currentPosition + 30_000)
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> player.seekTo((player.currentPosition - 30_000).coerceAtLeast(0))
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT -> player.seekToNextMediaItem()
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> player.seekToPreviousMediaItem()
            KeyEvent.KEYCODE_MENU -> pickZip()
            else -> return super.onKeyDown(k, e)
        }
        return true
    }

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); player.release(); super.onDestroy() }
}
