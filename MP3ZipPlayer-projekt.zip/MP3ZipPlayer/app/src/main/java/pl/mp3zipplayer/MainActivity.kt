/*
 * MP3ZipPlayer – Google TV / Android TV
 *
 * === app/build.gradle.kts (fragmenty) ===
 * android { namespace = "pl.mp3zipplayer"; compileSdk = 34
 *   defaultConfig { applicationId = "pl.mp3zipplayer"; minSdk = 24; targetSdk = 34 }
 *   kotlinOptions { jvmTarget = "17" } }
 * dependencies { implementation("androidx.media3:media3-exoplayer:1.4.1") }
 *
 * === AndroidManifest.xml ===
 * <uses-feature android:name="android.software.leanback" android:required="false"/>
 * <uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
 * <application android:label="MP3ZipPlayer" android:theme="@android:style/Theme.Material.NoActionBar">
 *   <activity android:name=".MainActivity" android:exported="true">
 *     <intent-filter>
 *       <action android:name="android.intent.action.MAIN"/>
 *       <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>
 *       <category android:name="android.intent.category.LAUNCHER"/>
 *     </intent-filter>
 *     <intent-filter>
 *       <action android:name="android.intent.action.VIEW"/>
 *       <category android:name="android.intent.category.DEFAULT"/>
 *       <data android:mimeType="application/zip"/>
 *     </intent-filter>
 *   </activity>
 * </application>
 *
 * Sterowanie pilotem: OK = play/pauza, lewo/prawo = -/+30 s,
 * góra/dół = poprzedni/następny plik, MENU (lub OK gdy brak zipa) = wybór zip.
 */
package pl.mp3zipplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private class Track(val name: String, val file: File, var durMs: Long = 0)

    private lateinit var player: ExoPlayer
    private lateinit var cover: ImageView
    private lateinit var title: TextView
    private lateinit var list: ListView
    private lateinit var fileLeft: TextView
    private lateinit var totalLeft: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private val tracks = mutableListOf<Track>()
    private val ui = Handler(Looper.getMainLooper())
    private val audioExt = setOf("mp3", "m4a", "m4b", "ogg", "opus", "flac", "wav", "aac")
    private val imgExt = setOf("jpg", "jpeg", "png", "webp")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi()
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(m: MediaItem?, r: Int) = highlight()
        })
        ui.post(ticker)
        val uri = intent?.data
        if (uri != null) loadZip(uri) else pickZip()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.BLACK); setPadding(48, 32, 48, 32)
        }
        cover = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(cover, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 0, 0, 0) }
        title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 26f; text = "MP3ZipPlayer" }
        list = ListView(this).apply { isFocusable = false; choiceMode = ListView.CHOICE_MODE_SINGLE }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_activated_1, mutableListOf<String>())
        list.adapter = adapter
        fileLeft = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 22f }
        totalLeft = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 22f }
        right.addView(title)
        right.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        right.addView(fileLeft); right.addView(totalLeft)
        root.addView(right, LinearLayout.LayoutParams(0, -1, 1.3f))
        setContentView(root)
    }

    private fun pickZip() {
        val roots = mutableListOf<File>()
        getExternalFilesDir(null)?.let { roots += it }
        for (d in listOf("Download", "Documents", "Music", "Audiobooks", "Movies"))
            roots += File("/sdcard/$d")
        File("/storage").listFiles()?.filter { it.name != "emulated" && it.name != "self" }?.let { roots += it }
        val zips = roots.distinct().flatMap { r ->
            try { r.walkTopDown().maxDepth(3).filter { it.isFile && it.extension.lowercase() == "zip" }.toList() }
            catch (e: Exception) { emptyList() }
        }
        if (zips.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Brak plików zip")
                .setMessage("Wgraj zip do:\n${getExternalFilesDir(null)}\n(np. adb push plik.zip tamta_sciezka/)\n\nlub do Download po nadaniu uprawnień:\nadb shell appops set pl.mp3zipplayer MANAGE_EXTERNAL_STORAGE allow")
                .setPositiveButton("Szukaj ponownie") { _, _ -> pickZip() }
                .setNegativeButton("Zamknij", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Wybierz zip")
            .setItems(zips.map { it.name }.toTypedArray()) { _, i -> loadZip(Uri.fromFile(zips[i])) }
            .show()
    }

    @Deprecated("ok")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        d?.data?.let { loadZip(it) }
    }

    private fun natural(s: String) = Regex("\\d+|\\D+").findAll(s.lowercase()).map {
        it.value.let { v -> if (v[0].isDigit()) v.padStart(12, '0') else v }
    }.joinToString("")

    private fun openIn(uri: Uri): java.io.InputStream =
        if (uri.scheme == "file") java.io.FileInputStream(File(uri.path!!)) else contentResolver.openInputStream(uri)!!

    private fun loadZip(uri: Uri) {
        title.text = "Rozpakowuję…"
        Thread {
            try { doLoad(uri) } catch (e: Throwable) {
                runOnUiThread {
                    title.text = "MP3ZipPlayer"
                    AlertDialog.Builder(this).setTitle("Błąd").setMessage(e.toString())
                        .setPositiveButton("OK", null).show()
                }
            }
        }.start()
    }

    private fun decodeCover(path: String): android.graphics.Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var sample = 1
        while (o.outWidth / sample > 2048 || o.outHeight / sample > 2048) sample *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun doLoad(uri: Uri) {
        val dir = File(cacheDir, "book")
        var found = mutableListOf<Pair<String, File>>()
        var coverFile: File? = null
        var coverScore = -1
        var lastErr: Throwable? = null
        for (cs in listOf(Charsets.UTF_8, charset("windows-1250"), charset("IBM852"))) {
            try {
                dir.deleteRecursively(); dir.mkdirs()
                found = mutableListOf(); coverFile = null; coverScore = -1
                var i = 0
                ZipInputStream(openIn(uri).buffered(), cs).use { zis ->
                    var e = zis.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) {
                            val base = e.name.substringAfterLast('/')
                            val ext = base.substringAfterLast('.', "").lowercase()
                            if (ext in audioExt || ext in imgExt) {
                                val f = File(dir, "${i++}.$ext")
                                f.outputStream().use { zis.copyTo(it) }
                                if (ext in audioExt) found += e.name to f
                                else {
                                    val n = base.lowercase()
                                    val sc = when {
                                        "cover" in n || "okładka" in n || "okladka" in n -> 3
                                        "folder" in n || "front" in n || "album" in n -> 2
                                        else -> 1
                                    }
                                    if (sc > coverScore) { coverScore = sc; coverFile = f }
                                }
                            }
                        }
                        e = zis.nextEntry
                    }
                }
                lastErr = null
                break
            } catch (e: Exception) { lastErr = e }
        }
        lastErr?.let { throw it }
        if (found.isEmpty()) throw Exception("Brak plików audio w zipie")
        found.sortBy { natural(it.first) }
        val tl = found.map { Track(it.first.substringAfterLast('/').substringBeforeLast('.'), it.second) }
        val mmr = MediaMetadataRetriever()
        for (t in tl) {
            try {
                mmr.setDataSource(t.file.absolutePath)
                t.durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0
            } catch (e: Exception) { t.durMs = 0 }
        }
        var bmp: android.graphics.Bitmap? = null
        try { coverFile?.let { bmp = decodeCover(it.absolutePath) } } catch (e: Throwable) { }
        if (bmp == null) try {
            mmr.setDataSource(tl[0].file.absolutePath)
            mmr.embeddedPicture?.let { bmp = BitmapFactory.decodeByteArray(it, 0, it.size) }
        } catch (e: Throwable) { }
        mmr.release()
        runOnUiThread {
            tracks.clear(); tracks.addAll(tl)
            adapter.clear(); adapter.addAll(tl.map { it.name })
            cover.setImageBitmap(bmp)
            title.text = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "MP3ZipPlayer"
            player.setMediaItems(tl.map { MediaItem.fromUri(Uri.fromFile(it.file)) })
            player.prepare(); player.play(); highlight()
        }
    }

    private fun highlight() {
        val i = player.currentMediaItemIndex
        if (i in tracks.indices) { list.setItemChecked(i, true); list.smoothScrollToPosition(i) }
    }

    private fun fmt(ms: Long): String {
        val s = (ms.coerceAtLeast(0)) / 1000
        return "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    }

    private val ticker = object : Runnable {
        override fun run() {
            val i = player.currentMediaItemIndex
            if (i in tracks.indices) {
                val leftFile = tracks[i].durMs - player.currentPosition
                val leftTotal = leftFile + tracks.drop(i + 1).sumOf { it.durMs }
                fileLeft.text = "Do końca pliku: ${fmt(leftFile)}"
                totalLeft.text = "Do końca wszystkich: ${fmt(leftTotal)}"
            }
            ui.postDelayed(this, 500)
        }
    }

    private var lastSeekT = 0L

    private fun seekBy(deltaMs: Long) {
        val i = player.currentMediaItemIndex
        val target = player.currentPosition + deltaMs
        val dur = if (i in tracks.indices && tracks[i].durMs > 0) tracks[i].durMs else player.duration.coerceAtLeast(0)
        if (dur > 0 && target > dur && i < tracks.size - 1) { player.seekTo(i + 1, 0); return }
        if (target < 0 && i > 0) { player.seekTo(i - 1, (tracks[i - 1].durMs + target).coerceAtLeast(0)); return }
        player.seekTo(if (dur > 0) target.coerceIn(0, dur) else target.coerceAtLeast(0))
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        val dir = when (k) {
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> 1
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> -1
            else -> 0
        }
        if (dir != 0) {
            val now = SystemClock.uptimeMillis()
            if (e.repeatCount == 0) seekBy(dir * 30_000L)          // 1 klik = 30 s
            else seekBy(dir * (now - lastSeekT) * 60)              // przytrzymanie: 1 s = 1 min
            lastSeekT = now
            return true
        }
        when (k) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (e.repeatCount == 0) {
                    if (tracks.isEmpty()) pickZip() else if (player.isPlaying) player.pause() else player.play()
                }
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> player.play()
            KeyEvent.KEYCODE_MEDIA_PAUSE -> player.pause()
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT -> if (e.repeatCount == 0) player.seekToNextMediaItem()
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> if (e.repeatCount == 0) player.seekToPreviousMediaItem()
            KeyEvent.KEYCODE_MENU -> pickZip()
            else -> return super.onKeyDown(k, e)
        }
        return true
    }

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); player.release(); super.onDestroy() }
}
